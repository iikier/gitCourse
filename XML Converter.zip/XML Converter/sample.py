import requests
import sys
import xml.etree.ElementTree as ET
import base64

user = 'rotina'
pwd = 'QAwsedrf2011@@'

# http://tim-app-simpa01.acesita.com.br:81/SearchSvc/CVWebService.svc/

service = 'http://tim-app-simpa01.acesita.com.br:81/SearchSvc/CVWebService.svc/'

loginReq = '<DM2ContentIndexing_CheckCredentialReq mode="Webconsole" username="rotina" password="<<password>>" />'

# encode password in base64 for Python 3
pwd = bytes(pwd, encoding='utf8')
pwd = str(base64.b64encode(pwd), encoding='utf-8')
loginReq = loginReq.replace("<<password>>", pwd)

# Login request built. Send the request now:
r = requests.post(service + 'Login', data=loginReq)
token = None

# Check response code and check if the response has an attribute "token" set
if r.status_code == 200:
    root = ET.fromstring(r.text)
    if 'token' in root.attrib:
        token = root.attrib['token']
        print("Login Successful")
    else:
        print("Login Failed")
        sys.exit(0)
else:
    print('there was an error logging in')

# Login successful.
# 2. Get client props. Client Id is hard coded to 2.

clientId = "vmpseudoclient"
clientPropsReq = service + "client/" + clientId

# build headers with the received token
headers = {'Cookie2': token}
r = requests.get(clientPropsReq, headers=headers)
clientResp = r.text

print(type(clientResp))
# Parse response to get client name, host name and client description
client = ET.fromstring(clientResp)

print(type(client))
print(client)
print("chaves vmpseudoclient:")
print(client.keys())

VSPseudoClientsList = client.findall(".//VSPseudoClientsList")

print(type(VSPseudoClientsList))

print("separador")

print(type(VSPseudoClientsList[0][0]))

print(VSPseudoClientsList[0][0])
print("Guid do host: {}".format(VSPseudoClientsList[0][0].attrib["clientGUID"]))
print("HOstname: {}".format(VSPseudoClientsList[0][0].attrib["displayName"]))

print("\nTeste For\n")
for servidor in VSPseudoClientsList:
    print("Hostname: {}, GUID: {}".format(servidor[0].attrib["displayName"], servidor[0].attrib["clientGUID"]))

print("\nFim do Teste For\n")

# VM?guid=9ACCCD3A-148E-4946-8AF0-704C39332356
# print(vmStatusInfoList[0].attrib["name"])
clientId = "VM?guid=9ACCCD3A-148E-4946-8AF0-704C39332356"
clientPropsReq = service + clientId
# clientPropsReq = service + "client/" + clientId

# build headers with the received token
headers = {'Cookie2': token}
r = requests.get(clientPropsReq, headers=headers)
clientResp = r.text

# Parse response to get client name, host name and client description
client = ET.fromstring(clientResp)
# print(client.attrib["totalRecords"])
print(client.keys())

vmStatusInfoList = client.findall(".//vmStatusInfoList")
print(type(vmStatusInfoList))
print(len(vmStatusInfoList))

print("\nTeste For\n")
for servidor in vmStatusInfoList:
    print("Nome VM: {}".format(servidor.attrib["name"]))

print("\nFim do Teste For\n")

print(vmStatusInfoList[0].attrib["name"])

print(vmStatusInfoList[0].attrib["strGUID"])

cd = client.findall(".//vmStatusInfoList/pseudoClient")
print(cd[0].attrib["clientName"])

'''


Nome VM: AAWin10_AM
Nome VM: acaiaca_n0
Nome VM: ACE045
Nome VM: ACI-APC-COND01
Nome VM: ACI-APC-COND01
Nome VM: ACI-APC-DESS01
Nome VM: ACI-APC-KR01
Nome VM: ACI-APC-OPC01
Nome VM: ACI-APC-OPC02
pseudoClient

print ("clientGUID: " + VSPseudoClientsList[0].attrib["clientGUID"])
print ("Host Name: " + VSPseudoClientsList[0].attrib["displayName"])




cd = client.findall(".//clientProperties/client")
if 'clientDescription' in cd[0].attrib:
	print ("Client Desc: " + cd[0].attrib["clientDescription"])











jSonResponse = r.json()

print(jSonResponse)

ListaServidores = ["{}".format(vmName['name'].lower()) for vmName in
                   jSonResponse['name']]


print(ListaServidores)








activePhysicalNode = client.findall(".//ActivePhysicalNode")
print ("Client Name: " + activePhysicalNode[0].attrib["clientName"])
print ("Host Name: " + activePhysicalNode[0].attrib["hostName"])




cd = client.findall(".//clientProperties/client")
if 'clientDescription' in cd[0].attrib:
	print ("Client Desc: " + cd[0].attrib["clientDescription"])

clientProps = client.findall(".//clientProps")
if 'JobPriority' in clientProps[0].attrib:
	print ("Job Priority: " + clientProps[0].attrib["JobPriority"])

#3. Set client props
#The following request XML is hard coded here but can be read from a file and appropriate properties set.
updateClientProps = '<App_SetClientPropertiesRequest><clientProperties><clientProps JobPriority="<<jobPriority>>"></clientProps></clientProperties></App_SetClientPropertiesRequest>'
updateClientProps = updateClientProps.replace("<<jobPriority>>", "7")

#Fire the request and print output

r = requests.post(clientPropsReq,data=updateClientProps, headers=headers)
resp = r.text
print (resp)
respRoot = ET.fromstring(resp)
respEle = respRoot.findall(".//response")
errorCode = respEle[0].attrib["errorCode"]

if errorCode == "0":
	print ("Client properties set successfully")
else:
	print ("Client properties could not be set. Error Code: " + errorCode )
'''