# pip install requests xmltodict dicttoxml

import requests
import xmltodict
import dicttoxml
import xml.etree.ElementTree as ET

# Set the request parameters
# URL = 'https://tkshelpdev.service-now.com'
# URL = "https://tkshelpdev.service-now.com/api/now/table/sc_task/7a7f63bd1bee60d04ef531901a4bcbfb"
URL = 'https://tkshelpdev.service-now.com/sc_task_list.do?sysparm_query=assignment_group.name=AMS-TI-CLOUD^active=true'
# Eg. User name="username", Password="password" for this code sample.
user = 'TrueSight'
pwd = 'TSsN_0720#'

# Set proper headers
headers = {"Accept": "application/xml"}

# Do the HTTP request
response = requests.get(URL, auth=(user, pwd), headers=headers)

# Check for HTTP codes other than 200
if response.status_code != 200:
    print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:', response.content)
    exit()

# Decode the XML response into a dictionary and use the data
# print(response.content)

responsex = response.text
root = ET.fromstring(responsex)
print(root)

# raiz do XML
'''
itemResponse = root.findall(".//response/results")

#cd = itemResponse.findall(".//vmStatusInfoList/pseudoClient")
print(itemResponse[0].attrib["number"])

ListTasks = []
for level in root:
    #ListTasks.append("{}".format(level.attrib))
    print(level.tag, level.attrib)

'''

# for level in levels:
#     name = level.find('number').text # encontre as variaveis que vão ser usadas
#     code = level.find('short_description').text
#     code = level.find('short_description').text
#     code = level.find('short_description').text
#     tfFile = open('variables.tf','a')
#     tfFile.write("Name: " + name)
#     tfFile.write("Code: " + code)
#     tfFile.close()
