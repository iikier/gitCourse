# pip install requests xmltodict dicttoxml

# Need to install requests package for python
import json
import xml.etree.ElementTree as ET
import xmltodict
import dicttoxml
import requests

# Set the request parameters
url = 'https://tkshelpdev.service-now.com/api/now/table/sc_task?sysparm_query=assignment_group.name=AMS-TI-CLOUD^active=true'
# url = 'https://tkshelpdev.service-now.com/api/now/table/sc_task_list.do?sysparm_query=assignment_group.name=AMS-TI-CLOUD^active=true'
# url = 'https://tkshelpdev.service-now.com/api/now/table/sc_request/505fe77d1bee60d04ef531901a4bcb74'
# url = 'https://tkshelpdev.service-now.com/api/now/table/sc_req_item/d45fe77d1bee60d04ef531901a4bcb74'

# Eg. User name="username", Password="password" for this code sample.
user = 'TrueSight'
pwd = 'TSsN_0720#'


# Set proper headers
headers = {"Accept": "application/json"}

# Do the HTTP request
response = requests.get(url, auth=(user, pwd), headers=headers)

# Check for HTTP codes other than 204
if response.status_code != 200:
    print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:', response.json())
    exit()


text = json.dumps(response.json(), sort_keys=True, indent=4)
print(text)
# responsex = response.json()

# encontre as variaveis que vão ser usadas
# name = responsex['result']['number']
# code = responsex['result']['short_description']

#     tfFile = open('variables.tf','a')
#     tfFile.write("Name: " + name)
#     tfFile.write("Code: " + code)
#     tfFile.close()

